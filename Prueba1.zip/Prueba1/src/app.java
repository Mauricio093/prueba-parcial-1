
import java.io.IOException;
import java.util.List;
import java.util.Scanner;

public class app {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        servicio_usuario servicio = new servicio_usuario();
        int opcion = 0;

        do {
            System.out.println("------------------------------");
            System.out.println("\n===== MENU =====");
            System.out.println("1. Registrar Usuario");
            System.out.println("2. Listar Usuarios");
            System.out.println("3. Salir");
            System.out.println("Seleccione una de las opciones");
            System.out.println("------------------------------");

            opcion = sc.nextInt();
            sc.nextLine();

            try {

                switch (opcion) {
                    case 1:
                        System.out.println("Ingrese nnombre: ");
                        String nombre = sc.nextLine();
                        System.out.println("Ingrese el correo");
                        String correo = sc.nextLine();

                        servicio.registrarUsuario(nombre, correo);
                        System.out.println("El Usuario ha sido registrado exitosamente.");
                        break;

                    case 2:
                        List<usuario> lista = servicio.obtenerUsuarios();
                        if (lista.isEmpty()) {
                            System.out.println("No hay usuarion en la lista");
                        } else {
                            for (usuario u : lista) {
                                System.out.println("Nombre " + u.getNombre() + "Correo: " + u.getCorreo());
                            }
                        }
                        break;

                    case 3:
                        System.out.println("Saliendo, Espere un momento... ");
                        break;

                    default:
                        System.out.println("Opción inválida.");

                }

            } catch (IllegalArgumentException e) {
                System.out.println("Error de validación: " + e.getMessage());
            } catch (IOException e) {
                System.out.println("Error al manejar el archivo: " + e.getMessage());
            }

        } while (opcion != 3);

        sc.close();
    }
}
