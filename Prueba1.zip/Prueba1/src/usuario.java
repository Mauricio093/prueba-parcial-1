/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author laboratorio
 */
public class usuario {

    
        
    private String nombre;
    private String correo;
    
    public usuario(String nombre,  String correo){
        this.nombre = nombre;
        this.correo = correo;
        
    }
    

    public String getNombre(){
        return nombre;
    }
    
    public String getCorreo(){
        return correo;
    }
    
}

