
import java.io.IOException;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author laboratorio
 */
public class servicio_usuario {

    private UsuarioDAOArchivo dao = new UsuarioDAOArchivo();

    public void registrarUsuario(String nombre, String correo) throws IOException {
        //validaciones 
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacio. ");

        }
        if (correo == null || !correo.contains("@")) {
            throw new IllegalArgumentException("El correo tienen que llevar un dominio correcto. ");
        }
        usuario us = new usuario(nombre.trim(), correo.trim());
        dao.guardarUsuario(us);
        
    }
    //obtener listas.
    public List<usuario> obtenerUsuarios() throws IOException {
        return dao.listarUsuarios();
    }
}
