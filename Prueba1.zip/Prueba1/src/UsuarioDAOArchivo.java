
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author laboratorio
 */

public class UsuarioDAOArchivo {
  private final String archivo = "usuarios.txt";

    // Guardar usuario en el archivo
    public void guardarUsuario(usuario u) throws IOException {

        try (PrintWriter pw = new PrintWriter(new FileWriter(archivo, true))) {
            pw.println(u.getNombre() + "," + u.getCorreo());
        }
    }

    // Listar usuarios del archivo
    public List<usuario> listarUsuarios() throws IOException {

        List<usuario> usuarios = new ArrayList<>();

        File file = new File(archivo);

        if (!file.exists()) {
            file.createNewFile(); // crea el archivo si no existe
            return usuarios;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {

            String linea;

            while ((linea = br.readLine()) != null) {

                String[] partes = linea.split(",");

                if (partes.length == 2) {
                    String nombre = partes[0];
                    String correo = partes[1];

                    usuario u = new usuario(nombre, correo);
                    usuarios.add(u);
                }
            }
        }

        return usuarios;
    }

}
